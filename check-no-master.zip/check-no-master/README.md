# check-no
number is checked for positive and negative 
